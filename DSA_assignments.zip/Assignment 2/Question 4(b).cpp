//Write a program to reverse a string

#include <iostream>
#include <string>
using namespace std;

int main(){
    
    string str;
    cout<<"Enter a string (without spaces): ";
    cin>>str;
    string rev= "";
    for(int i=str.length()-1;i>=0;i--){
        rev+=str[i];
    }
    cout<<"Reversed string is: "<<rev<<endl;
    return 0;
}